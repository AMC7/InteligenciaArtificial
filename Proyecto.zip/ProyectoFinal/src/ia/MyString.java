/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ia;

/**
 *
 * @author antonio
 */
public class MyString {
    
    public static String str(Object o){
        return String.valueOf(o);
    }
    public static String str(double o){
        return String.valueOf(o);
    }
     public static String str(Double o){
        return String.valueOf(o);
    }
    
}
