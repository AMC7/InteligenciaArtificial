/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ia;

import static ia.MyString.str;
import static ia.Print.p;
import ia.Proyecto.Mapa;
import java.util.Random;
/**Clase que representa los muebles*/
public class Mueble{

    /**Todos estos arrelos representan la manera en que se visualizaran
     los objetos en el mapa*/
     private static final Tipo[][] SILLAARRAY= {{Tipo.OBSTACULO}};
     private static final Tipo[][] ESCRITORIOARRAY={{Tipo.OBSTACULO,Tipo.OBSTACULO},{Tipo.OBSTACULO,Tipo.OBSTACULO}};
     private static final Tipo[][] LIBREROARRAY={{Tipo.OBSTACULO,Tipo.OBSTACULO},{Tipo.VACIO,Tipo.OBSTACULO}};
     private static final Tipo[][] SILLONARRAY={{Tipo.OBSTACULO,Tipo.VACIO},{Tipo.OBSTACULO,Tipo.VACIO},{Tipo.OBSTACULO,Tipo.VACIO}};
     private static final Tipo[][] MESAARRAY={{Tipo.OBSTACULO,Tipo.OBSTACULO},{Tipo.VACIO,Tipo.OBSTACULO},{Tipo.VACIO,Tipo.OBSTACULO}, {Tipo.VACIO,Tipo.OBSTACULO}};
   
     private MuebleAux mueble;
     private  final MuebleAux[] values;

    public MuebleAux[] getValues() {
        return values;
    }
    public MuebleAux getMueble() {
        return mueble;
    }

    public void setMueble(MuebleAux mueble) {
        this.mueble = mueble;
     }

    public Mueble(MuebleAux mueble) {
        this.mueble = mueble;
        this.values=MuebleAux.values();
    }

    public Mueble() {
        Random a=new Random();
        this.mueble=MuebleAux.values()[a.nextInt(MuebleAux.values().length)];
        this.values=MuebleAux.values();
    }

    @Override
    public String toString() {
        return  str(mueble);
    }
    
    /**
     *Pinta los muebles
     * @param mapa
     * @param p1
     * @return 
     */
    public Punto pinta(Mapa mapa,Punto p1){
        int j=0;
        for (int i = 0; i <mueble.alto&&i+p1.getX()<mapa.renglones; i++)
            for (j = 0; j < mueble.ancho&&j+p1.getY()<mapa.columnas;j++) 
                    mapa.mundo[i+(int)p1.getX()][j+(int)p1.getY()].tipo=mueble.visual[j][i];  
              
              
        if(2*mueble.alto+p1.getY()>=mapa.columnas){
            p1.addX(3);  
            p1.setY(-1);
        }else    
            p1.addY(j);
        
        return p1;
    }
    
    /**Esta enum guarda las 5 cinstantes , que son los muebles*/
   public enum MuebleAux {

        SILLA(SILLAARRAY),ESCRITORIO(ESCRITORIOARRAY),LIBRERO(LIBREROARRAY)
       ,SILLON(SILLONARRAY),MESA(MESAARRAY);

        public int getAncho() {
            return ancho;
        }

        public int getAlto() {
            return alto;
        }


            private final int ancho;
            private final int alto;
            private final  Tipo[][] visual;
            MuebleAux(Tipo[][] visual){
                this.visual=visual;  
                this.ancho=visual.length;
                this.alto=visual[0].length;
            }

         /**
          *
          * @return
          */
         @SuppressWarnings("NonPublicExported")
             public Tipo[][]  getVis(){
                return this.visual;
            }
    }
}