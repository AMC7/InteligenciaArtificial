/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ia;
import static ia.Print.*;
import static java.lang.Math.*;
import java.util.Arrays;

/**
 *
 * @author antonio
 */
public class Hola{ 
       public static double aRadianes(int grado){
           double temp=(double)grado;
           return temp*PI/180.0;
       }
    public static void main(String[]args){
       p(exp(-7117.584584480472));
        
    }
}
