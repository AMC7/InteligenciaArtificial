package ia;
import static ia.Print.*;
import java.util.Arrays;
import java.util.Random;
import static java.lang.Math.*;
/**@version 1.0
   @author Antonio Martinez Cruz*/
public class IntArray{
	int [] a;
	IntArray(int longitud){
		a=new int[longitud];	
		for(int i=0;i<a.length;i++)
			a[i]=i;
	}
	IntArray(){
	  a=new int[15];
	  Random random= new Random();
	  for(int i=0;i<a.length;i++)
	  	a[i]=abs(random.nextInt()%30);
	}

        @Override
	public String toString(){
		return Arrays.toString(a);
	}

	public int max(){
		int max=a[0];
		for(int i=0;i<a.length;i++)
			if(a[i]>max)
				max=a[i];
		return max;	
	}

	public int min(){
		int min=a[0];
		for(int i=0;i<a.length;i++)
			if(a[i]<min)
				min=a[i];
		return min;	
	}

}
