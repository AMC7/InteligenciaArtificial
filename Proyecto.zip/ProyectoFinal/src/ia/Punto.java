package ia;
import static java.lang.Math.*;
/**@version 1.0
   @author Antonio Martinez Cruz*/
public class Punto{
	private double x;
	private double y;
		
		Punto(){
			
		}
                
                Punto(Punto aux){
                    x=aux.getX();
                    y=aux.getY();
                }
		 
		Punto(double x,double y){
                    this.x=x;
                    this.y=y;
                }
		
                Punto(double x){
                    this.x=x;
                    this.y=x;
                }
                @Override
		public String toString(){
			return "("+String.valueOf(getX())+","+String.valueOf(getY())+")";
		}
		public void setX(double x){
			this.x=x;
		}
		
		public void setY(double y){
			this.y=y;
		}
                
                public Punto invierte(){
                    double temp=x;
                    x=y;
                    y=temp;
                    return this;
                }
                public Punto sumaPunto(Punto p1){
                        this.x+=p1.x;
                        this.y+=p1.y;
                        return this;
                }
                
                public Punto restaPunto(Punto p1){
                    this.x-=p1.x;
                    this.y-=p1.y;
                    return this;
                   
                }
                public Punto multiplicaPunto(Punto p1){
                        this.x*=p1.getX();
                        this.y*=p1.getY();
                        return this;
                }
		
                public Punto multiplica(double f){
                    x=(double)((double)x*f);
                    y=(double)((double)y*f);
                    return this;
                }
                public Punto divide(double a){
                    this.multiplica((double)(1)/a);
                    return this;
                }
		public Punto addY(double aSumar){
                        y+=aSumar;
                       return this; 
                }
                public Punto addX(double aSumar){
                        x+=aSumar;
                        return this;
                }
                public double getX(){
			return x;                
		}
		public double getY(){
			return y;
		}
                
                public double getDistacia(Punto otro){
                  return sqrt(pow(x-otro.getX(),2)+pow(y-otro.getY(),2));
                }
               
                public boolean equals(Punto otro){
                    return getX()==otro.getX()&&getY()==otro.getY();
                }
               
	public static void main(String [] args){
	}
}
