package ia;
import java.util.Arrays;
/**Clase para imprimir archivos
@author Antonio Martinez Cruz
@version 0.0.4
*/
public class Print{
   public static void p(String o){
      System.out.println(o);
   }
    /**Metodo estatico que imprime un objeto*/
   public static void p(Object o){
   System.out.println(o.toString());
   }
  
   /**Metodo estatico que imprime un entero*/ 
   public static void p(int i){
   System.out.println(i);
   }
   /**Metodo estatico que imprime un double*/
   public static void p(double i){
   System.out.println(i);
   }
   /**Metodo estatico que imprime un arreglo de objeto
     * @param a*/
   public static void p(Object[]a){
   System.out.println(Arrays.toString(a));
   }
   /**Metodo estatico que imprime un arreglo de int
     * @param a*/
   public static void p(int []a){
   System.out.println(Arrays.toString(a));
   }	
   
   public static void p(double []a){
        System.out.println(Arrays.toString(a));
   }
   public static void p(double [][]a){
       for(double[]array:a)
           p(array);
  
   }
   public static void p(boolean[]a){
        System.out.println(Arrays.toString(a));
  
   }
   
   public static void p(int [][]a){
       for(int[]array:a)
           p(array);
   }
   
   public static void p(boolean [][] a){
       for (boolean[] a1 : a) 
           p(a1);
       
   }

}
