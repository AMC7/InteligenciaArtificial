/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ia;

import static ia.Print.p;
import processing.core.PApplet;
import processing.core.PFont;
import static ia.MyString.str;
import java.util.Random;
import java.awt.Color;
import static processing.core.PApplet.abs;
import java.util.Arrays;
import java.util.Collections;
import java.text.NumberFormat;
import java.text.DecimalFormat;
/**
 *
 * @author Verónica Arriola
 */
public class Proyecto extends PApplet {

    PFont fuente;               // Fuente para mostrar texto en pantalla
    int tamanioMosaico = 60;    // Tamanio de cada mosaico cuadrado (en pixeles).
    int columnas = 21;
    int renglones = 10;
    Random random = new Random();
    Mapa mapa;
    Robot robot;
    Robot robotaux;
    int libres;
    double alfa;
    Robot  [][][] mundo= new Robot[renglones][columnas][8];
    Robot [][][] mundoAnterior= new Robot[renglones][columnas][8];
   
    /**Copia el contenido de un arreglo en otro*/
    void copia(Robot[][][] mundo,Robot[][][] mundoAnterior){
        for (int i = 0; i < renglones; i++) 
            for (int j = 0; j <columnas; j++) 
                for (int k = 0; k < 8; k++) {
                    mundo[i][j][k]=mundoAnterior[i][j][k];
                }
        
    }
        
    /**Pinta un circulo de processings*/
    void pintaCirculo(Punto punto,int radio,Color color){
        stroke(color.getRed(),color.getGreen(),color.getBlue());
        fill(color.getRed(),color.getGreen(),color.getBlue());        
        ellipse((int)punto.getX(),(int)punto.getY(),radio,radio);
    }
    
    /**Pinta una linea de processing*/
    void pintaLinea(Punto punto,Punto punto2,Color color){
        stroke(color.getRed(),color.getGreen(),color.getBlue());
        line((int)punto.getX(),(int)punto.getY(),(int)punto2.getX(),(int)punto2.getY());
    }
    /**Te regresa la formula del algoritmo*/
    double[] getFormula(Robot actual,Robot s, int caso){
            double [] form=null; 
            double a;
            double b;
            switch(caso){
                case 0:
                    form = new double [8];    
                    for (int i = 0; i < form.length; i++) {
                        a=1./((Math.sqrt(2*Math.PI)*s.laser[i].desviacion));
                        b=(-Math.pow(actual.laser[i].media-s.laser[i].media,2))/10000*Math.pow(s.laser[i].desviacion,2);    
                        form[i]= a*Math.exp(b)*3;
                        if(form[i]==0){
                         }
                       
                    }
                     break;
                case 1:
                     form = new double [1]; 
                     a=1./((Math.sqrt(2*Math.PI)*s.giroSensor.desviacion));
                     //b=Math.pow(s.giroSensor.medicion-(actual.giroActual.medicion-s.giroAnterior.medicion), 2)/Math.pow(s.giroSensor.desviacion,2);
                     b=(Math.pow(s.giroSensor.medicion-(actual.giroActual.medicion-s.giroAnterior.medicion), 2)/Math.pow(s.giroSensor.desviacion,2));
                     form[0]= a*Math.exp(b/10000);
                     Double jaja= form[0];
                     if(jaja.isInfinite()){
                       // p("fallo 2");
                     }
                      break;
                case 2:
                     form = new double [1]; 
                     a=1./((Math.sqrt(2*Math.PI)*s.odometrico.desviacion));
                     double temp1=Math.pow(s.pAnterior.getX()+s.odometrico.medicion*Math.cos(s.giroAnterior.medicion)-s.p.getX(), 2);
                     double temp2=Math.pow(s.pAnterior.getY()+s.odometrico.medicion*Math.sin(s.giroAnterior.medicion)-s.p.getY(), 2);;
                     double temp3=Math.pow(s.giroAnterior.medicion-s.giroActual.medicion,2);
                     b=((-1./(2.*Math.pow(s.odometrico.desviacion,2)))*(temp1+temp2+temp3))/5000;
                     form[0]= a*Math.exp(b);
                     break;
               
            }
            return form;
        }
    /**Clase sensor que tiene todo lo necesario para trabajar con un sensor*/
    class Sensor{
        double media;
        double desviacion;
        double medicion;
        Punto choque;

        public Sensor(double media, double medicion, Punto choque,double desviacion) {
            this.media = media;
            this.medicion = medicion;
            this.choque = choque;
            this.desviacion=desviacion;
        }
      
        public Sensor(double desviacion) {
            this.media = 0;
            this.medicion =0;
            this.choque = new Punto();
            this.desviacion=desviacion;
        }
        
        public Sensor(Sensor a) {
            this.media = a.media;
            this.medicion =a.medicion;
            this.choque = a.choque;
            this.desviacion=a.desviacion;
        }
       
         
        public void setMedia(double media) {
            this.media = media;
            double gaussian=new Random().nextGaussian();
            double temp=gaussian*(double)desviacion;
            medicion=media+temp;
        
        }
        
        public void setChoque(Punto choque,Punto aux) {
            this.choque = aux;
            setMedia(choque.getDistacia(aux));
        }
        
        @Override
        public String toString(){
            NumberFormat formatter = new DecimalFormat("#.###");
            return String.valueOf(formatter.format(medicion));
        }
        
    }
    
    /**Clase robot hace todo lo que el robot necesita hacer*/
    class Robot{
        Punto p = new Punto();
        Punto pAnterior=new Punto();
        Punto direccion=new Punto();
        Color color;
        Punto [] puntos;
        Sensor[] laser= new Sensor[8];
        Sensor  odometrico   = new Sensor(2);
        Sensor  giroAnterior = new Sensor(0.2);
        Sensor  giroActual   = new Sensor(0.2);
        Sensor  giroSensor   = new Sensor(0.2);
        double creencia;
        
        
        private boolean getBool(){
         return p.getX()>=0&&p.getY()>=0&&p.getX()<columnas*tamanioMosaico&& p.getY()<renglones*tamanioMosaico; 
        }
         
        private void initLaser(){
            for(int i=0;i<laser.length;i++){
                laser[i]=new Sensor(1);
            }
        }
        
        void ponSensor(Punto punto,int i){
            Robot temp = new Robot(this);  
            do{
              temp.p.sumaPunto(punto);  
            }while(temp.getBool()&&  temp.getMosaico().tipo.equals(Tipo.VACIO));
          laser[i].setChoque(p,temp.p );
        }
        
        void initPunto(double avance){
            puntos=new Punto[8];
            puntos[0]=new Punto(-avance,-avance);
            puntos[1]=new Punto(0,-avance);
            puntos[2]=new Punto(avance,-avance);
            puntos[3]=new Punto(-avance,0);
            puntos[4]=new Punto(avance,0);   
            puntos[5]=new Punto(-avance,avance);   
            puntos[6]=new Punto(0,avance);
            puntos[7]=new Punto(avance,avance);             
        }
        private void sensores(){
          initPunto(1);
          for(int i=0;i<8;i++)
              ponSensor(puntos[i],i);
        }
        
        Robot(){
            initLaser();
            encuentra();
            sensores();
            this.creencia=0;
        }
        Robot(Punto p){
            this.p=p;
            direccion=new Punto(p);
            initLaser();
            sensores();
            this.creencia=0;
        }
        Robot(Robot b){
           p=new Punto(b.p);
           direccion=new Punto(p);
           laser=b.laser;
           this.creencia=b.creencia;
        }
        
        void initGiroSensor(){
           giroSensor.media=Math.abs(giroAnterior.media-giroActual.media);
           giroSensor.medicion=Math.abs(giroAnterior.medicion-giroActual.medicion);
           giroSensor.choque=new Punto();
        }
        void pinta(){
           if(color==null){
               pintaCirculo(p,15,new Color(0,255,0));
           }else{
               pintaCirculo(p,15,color); 
           }
           pintaLinea(p,direccion,new Color(0,0,0));
           }
        
        Mosaico getMosaico(){
            Punto aux = new Punto(p);
            aux.divide(tamanioMosaico);
            aux.invierte();
            return mapa.getMosaico(aux);
        }
        private void encuentra(){
            do{
            p=new Punto(random.nextInt(mapa.renglones),random.nextInt(mapa.columnas));
            }while(mapa.getMosaico(p).tipo.equals(Tipo.OBSTACULO)); 
            p.invierte();
            p.multiplicaPunto(new Punto(tamanioMosaico));
            p.sumaPunto(new Punto((int)(tamanioMosaico/2)));
            direccion= new Punto(p);
            pAnterior= new Punto(p);
            sensores();
        }
    }
  
    @Override
    public void settings() {
        size(columnas * tamanioMosaico, renglones * tamanioMosaico + 70);
    }
    /** Configuracion inicial */
    @Override
    public void setup(){
        background(50);
        fuente = createFont("Arial",12,true);
        textFont(fuente, 12);
        mapa = new Mapa(columnas, renglones);
        for (int i = 0; i < mapa.renglones; i+=3){
            for (int j = 0; j < mapa.columnas; j++) {
                 Punto a=new Mueble().pinta(mapa,new Punto(i,j));
                 j=(int)a.getY();
                 if(i>=mapa.renglones)
                      break;
                i=(int)a.getX();
            }
        }    
        for (int i = 0; i < mapa.renglones; i++) 
            for (int j = 0; j < mapa.columnas; j++)
                if(mapa.mundo[i][j].tipo.equals(Tipo.VACIO))
                    libres++;
        
        for (int i = 0; i < mapa.renglones; i++) 
            for (int j = 0; j < mapa.columnas; j++)
                for (int k = 0; k < 8; k++) 
                    if(mapa.mundo[i][j].tipo.equals(Tipo.VACIO)){
                       Robot temp=new Robot(new Punto(j*tamanioMosaico+(tamanioMosaico/2),i*tamanioMosaico+(tamanioMosaico/2)));
                       temp.creencia=1./libres;
                       mundo[i][j][k]=new Robot(temp);
                       mundoAnterior[i][j][k]=new Robot(temp);
                    }else{
                        Robot temp = new Robot(new Punto(0,0));
                        mundo[i][j][k]=new Robot(temp);
                    }
                
        robot=new Robot();
        robotaux=new Robot(robot);
        
    }
    
    /**Metodo que te imprime donde esta el que tiene mayor proba*/
    public void dibujaAux(){
          double max = mundo[0][0][0].creencia;
          Robot temp=mundo[0][0][0];
          for (int i = 0; i < mapa.renglones; i++) 
            for (int j = 0; j < mapa.columnas; j++)
                for (int k = 0; k < 8; k++)
                   if(mundo[i][j][k].creencia>max){
                       max=mundo[i][j][k].creencia;
                       temp=new Robot(mundo[i][j][k]);
                       
                   }
          if(max==0){
              try{
              throw new Exception();
              }catch(Exception e){
                  e.printStackTrace();
              }
              
            }
          temp.color=Color.MAGENTA;
          p(max);
          temp.pinta();
    }
    /**Mueve el robot*/
    @Override
    public void keyPressed(){
     
        String a="qweadzsc";
        double [] grados={2.356194490192345, 1.5707963267948966, 0.7853981633974483, 3.141592653589793, 0.0, 3.9269908169872414, 4.71238898038469, 5.497787143782138};
        if(a.contains(str(key))){
        robot.initPunto(10);
        int indice=a.indexOf(key);
        Punto punto=robot.puntos[indice];
        Robot temp= new Robot(robot);
        temp.p.sumaPunto(punto);
        if(temp.getBool()){
            if(!temp.getMosaico().tipo.equals(Tipo.OBSTACULO)){
                robot.giroAnterior=new Sensor(robot.giroActual);
                robot.giroActual.setMedia(grados[indice]);
                robot.initGiroSensor();
                
                robot.odometrico.setMedia(robot.p.getDistacia(temp.p));
                robot.pAnterior=new Punto(robot.p);
                robot.p= new Punto(temp.p);
              }  
            robot.direccion=new Punto(robot.p).sumaPunto(punto);
            robot.sensores();
         }
        
        }
        
    }    
    
    /**Te dice si el robot se movio*/
    public boolean seMovio(){
        boolean bool= !robot.p.equals(robotaux.p);
        if(bool)
            robotaux= new Robot(robot);
         
            
        return bool;
    }
    /**Realiza la primer parte del algoritmo*/
    public void hasPrimer(){
        alfa=0.0;
        //Paso 1
        for (int i = 0; i < mapa.renglones; i++) 
            for (int j = 0; j < mapa.columnas; j++)
                for (int k = 0; k < 8; k++) 
                    if(mapa.mundo[i][j].tipo.equals(Tipo.VACIO)){
                        double [] a= this.getFormula(robot,mundoAnterior[i][j][k], 0);
                        mundo[i][j][k].creencia=a[k]*mundoAnterior[i][j][k].creencia;
                        if(mundo[i][j][k].creencia==0){
                           
                        }
                        alfa+=mundo[i][j][k].creencia;
                      }
        //Paso 2 
        for (int i = 0; i < mapa.renglones; i++) 
            for (int j = 0; j < mapa.columnas; j++)
                for (int k = 0; k < 8; k++) 
                    if(mapa.mundo[i][j].tipo.equals(Tipo.VACIO)){
                          mundo[i][j][k].creencia*=1./alfa;
                      }
        
           copia(mundoAnterior,mundo); 
    }
    /**Realiza la segunda parte del algoritmo*/
    public void hasSegundo(){
        for (int i = 0; i < mapa.renglones; i++) 
            for (int j = 0; j < mapa.columnas; j++)
                for (int k = 0; k < 8; k++) 
                    if(mapa.mundo[i][j].tipo.equals(Tipo.VACIO)){
                        Robot temp =new Robot(mundoAnterior[i][j][k]); 
                        mundo[i][j][k].creencia=getFormula(robot,temp,1)[0]*mundoAnterior[i][j][k].creencia;
                    }
        
        for (int i = 0; i < mapa.renglones; i++) 
            for (int j = 0; j < mapa.columnas; j++)
                for (int k = 0; k < 8; k++) 
                    if(mapa.mundo[i][j].tipo.equals(Tipo.VACIO)){
                        Robot temp =mundoAnterior[i][j][k]; 
                        mundo[i][j][k].creencia=getFormula(robot,temp,2)[0]*mundoAnterior[i][j][k].creencia;
                      }
        copia(mundoAnterior,mundo);
      
    }
    /** Dibuja la imagen en cada ciclo */
    @Override
    public void draw(){
       for(int i = 0; i < renglones; i++)
            for(int j = 0; j < columnas; j++){
               switch(mapa.mundo[i][j].tipo) {
                    case OBSTACULO:
                       stroke(0,0,0); fill(123,86,16); break; 
                    default:
                        stroke(255,255,255); fill(255,255,255); break;
                }
                rect(j*tamanioMosaico, i*tamanioMosaico, tamanioMosaico, tamanioMosaico);
               fill(0);
            }
      
       robot.pinta();
       
       if(!seMovio()){
          hasPrimer();
       }else{
         hasSegundo();  
       }
       dibujaAux();
    
        fill(0);
        rect(0, renglones * tamanioMosaico, columnas *  tamanioMosaico, 70);

        fill(0,200,0);
        rect(10, renglones * tamanioMosaico + 10, 20, 20);
        fill(255);
        text("Sensor de giro:"+robot.giroSensor, 40, renglones * tamanioMosaico + 30);

        fill(200,0,0);
        rect(10, renglones * tamanioMosaico + 30, 20, 20);
        fill(255);
        text("Sensor Odometrico:"+robot.odometrico, 40, renglones * tamanioMosaico + 50);

    }

    

    // --- Clase Mosaico
    // Representa cada casilla del mundo, corresponde a un estado posible del agente.
    class Mosaico{
        Tipo tipo = Tipo.VACIO;
        int renglon, columna;  // Coordenadas de este mosaico
      
        Mosaico(int renglon, int columna){
            this.renglon = renglon;
            this.columna = columna;
        }

        
    }

    // --- Clase Mapa
    class Mapa {
        public int columnas, renglones;
        Mosaico[][] mundo;

        Mapa(int columnas, int renglones) {
            this.columnas = columnas;
            this.renglones = renglones;
            mundo = new Mosaico[renglones][columnas];
            for(int i = 0; i < renglones; i++)
                for(int j = 0; j < columnas; j++)
                  mundo[i][j] = new Mosaico(i, j);
        }
        Mosaico getMosaico(Punto p1){
            return mapa.mundo[(int)p1.getX()][(int)p1.getY()]; 
        }
        void setMosaico(Punto p1, Mosaico m) {
            mapa.mundo[(int)p1.getX()][(int)p1.getY()]=m;
        }
        void setMosaicoTipo(Punto p1,Tipo m) {
            mapa.mundo[(int)p1.getX()][(int)p1.getY()].tipo=m;
        }
    }


    static public void main(String args[]) {
        PApplet.main(new String[] { "ia.Proyecto" });
    }

}
